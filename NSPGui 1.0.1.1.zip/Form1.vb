﻿Imports System.ComponentModel
Imports System.IO

Public Class Form1
    Dim files As List(Of String)

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FolderBrowserDialog1.ShowDialog(Me)
        TextBox1.Text = FolderBrowserDialog1.SelectedPath()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        BackgroundWorker1.WorkerSupportsCancellation = True
        BackgroundWorker1.WorkerReportsProgress = True
        If BackgroundWorker1.IsBusy Then
            If MsgBox("Are you sure you want to cancel?", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Are you sure?") = MsgBoxResult.Ok Then

                BackgroundWorker1.CancelAsync()
                Button2.Text = "&Make file"
                ProgressBar1.Value = ProgressBar1.Minimum
                Button1.Enabled = True
                Button3.Enabled = True
                Button4.Enabled = True
            End If

        Else


                If MsgBox("are you sure you want to merge all 00X files in the folder " & TextBox1.Text & " into files " & TextBox2.Text & "?", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Are you sure?") = MsgBoxResult.Ok Then

                Dim SourceOFD As New OpenFileDialog
                SourceOFD.Title = "Select Source File"

                Button2.Text = "Cancel"
                ProgressBar1.Minimum = 0
                ProgressBar1.Maximum = 100

                files = Directory.GetFiles(TextBox1.Text, "??").ToList()

                BackgroundWorker1.WorkerReportsProgress = True

                BackgroundWorker1.RunWorkerAsync(ProgressBar1)
                Button1.Enabled = False
                Button3.Enabled = False
                Button4.Enabled = False

            End If
        End If
    End Sub

    Private Sub Append(ByVal BaseFile As String, ByVal AddedFile As String, ProgressBar As ProgressBar)
        Using BW As New BinaryWriter(File.OpenWrite(BaseFile))
            Using BR As New BinaryReader(File.OpenRead(AddedFile))
                Dim B() As Byte
                Dim Percentage As Long = 0
                'ProgressBar.Minimum = 0
                'ProgressBar.Maximum = (BR.BaseStream.Length / 1024) / 1024

                BW.Seek(0, SeekOrigin.End)
                Do
                    If BackgroundWorker1.CancellationPending = True Then
                        Exit Do
                    End If
                    B = BR.ReadBytes(UShort.MaxValue)
                    BW.Write(B)
                    If BR.BaseStream.Length Mod 1024 = 0 Then
                        Percentage = ((BR.BaseStream.Position / 1024) / 1024) / 50

                        BackgroundWorker1.ReportProgress(Percentage)

                        '    Application.DoEvents()
                    End If
                Loop Until B.Length < UShort.MaxValue
                '  ProgressBar.Value = (BR.BaseStream.Length / 1024) / 1024
            End Using

        End Using
    End Sub

    Public Sub CopyFile(SourcePath As List(Of String), DestPath As String, ProgressBar As ProgressBar)
        Try
            If My.Computer.FileSystem.FileExists(DestPath) Then
                My.Computer.FileSystem.DeleteFile(DestPath)
            End If
            Dim FileBytes As Byte()


            For Each file As String In SourcePath
                'FileBytes = My.Computer.FileSystem.ReadAllBytes(file)
                Append(DestPath, file, ProgressBar)


            Next
            '      ProgressBar.Value = 100


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Copy Error")
        End Try
    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        SaveFileDialog1.Filter = "nsp (Nintentdo Submission Package)|*.nsp"
        SaveFileDialog1.DefaultExt = 0
        SaveFileDialog1.Title = "Select destination filename for merge"
        SaveFileDialog1.ShowDialog(Me)
        TextBox2.Text = SaveFileDialog1.FileName

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        checkSourceAndDest()

    End Sub

    Private Function checkSourceAndDest() As Boolean

        Button2.Enabled = TextBox1.Text.Length > 0 And TextBox2.Text.Length > 0



    End Function

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        checkSourceAndDest()
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork


        CopyFile(files, TextBox2.Text, e.Argument)



    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        If Not BackgroundWorker1.CancellationPending Then
            ProgressBar1.Value = e.ProgressPercentage
            ProgressBar1.Refresh()

        End If
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        ProgressBar1.Value = ProgressBar1.Maximum
        ProgressBar1.Refresh()

        MsgBox("Copying has finished.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Process complete!")


        ProgressBar1.Value = ProgressBar1.Minimum
        TextBox1.Text = ""
        TextBox2.Text = ""
        Button1.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        MsgBox("An NSP file merger" + vbCrLf + vbCrLf + "By Hayden Muggeridge" + vbCrLf + vbCrLf + Application.ProductVersion + vbCrLf + vbCrLf + "Copyright 2020", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "About")



    End Sub
End Class
